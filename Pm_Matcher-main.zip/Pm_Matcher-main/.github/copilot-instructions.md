<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# Internship Matcher System - Copilot Instructions

This is an AI-powered internship matching system with the following key components:

## Project Structure
- `backend/` - FastAPI REST API with matching algorithms
- `frontend/` - Streamlit user interface
- `database/` - SQLAlchemy models and database utilities
- `utils/` - Shared utilities including embeddings and AI integration

## Key Technologies
- **Backend**: FastAPI with SQLAlchemy ORM
- **Frontend**: Streamlit for web interface
- **Database**: SQLite for local storage
- **AI/ML**: sentence-transformers for embeddings, Groq API with Meta Llama for recommendations
- **Geography**: India-specific locations and districts
- **Social Categories**: OC (Open Category), BC (Backward Class), SC (Scheduled Caste), ST (Scheduled Tribe), Others

## Core Features
1. **Smart Matching**: Semantic skill matching using embeddings
2. **Affirmative Action**: Representation for rural districts, social categories, first-time applicants
3. **Capacity Management**: Industry-wise internship capacity tracking
4. **AI Recommendations**: LLM-powered contextual recommendations with explanations

## Coding Guidelines
- Use proper type hints and Pydantic models
- Implement proper error handling and validation
- Follow REST API best practices for FastAPI endpoints
- Use async/await patterns where appropriate
- Maintain clear separation between business logic and data access
- Include comprehensive docstrings and comments
- Handle Indian geographic data (states, districts, rural/urban classification)
- Implement fair and transparent affirmative action algorithms
